package com.example.automatedGreeting.service;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import com.example.automatedGreeting.model.Employee;
import com.example.automatedGreeting.repository.EmployeeRepository;

@Service
public class EmployeeService {

	@Autowired
	private EmployeeRepository employeeRepository;
	@Autowired
	private EmailSendService emailService;
	

	@Scheduled(cron = "0 15 18 * * *")
	public void sendBirthdayEmails() {
		List<Employee> employeesWithBirthdayToday = employeeRepository.findEmployeesWithBirthdayToday();

		for (Employee employee : employeesWithBirthdayToday) {
			String subject = "Happy Birthday!";
			String body = "Dear " + employee.getName()
					+ ",\n\nWishing you a very happy birthday!\n\nHave a great day and a year ahead...\n\nFrom \n\nAditya Mane";

			emailService.sendBirthdayEmail(employee.getEmailId(), subject, body);
			

		}
	}
}
